#include "MainScreen.h"

CMainScreen::CMainScreen(void)
: Select(0)
, Bgm_Intro_Bool(false)
{

}

CMainScreen::~CMainScreen(void)
{
}

int CMainScreen::Exit(void)
{
	if( MainScreen != NULL )
        MainScreen->Release();

	if( Start != NULL )
        Start->Release();

	if( Creater != NULL )
        Creater->Release();

	if( Quit != NULL )
        Quit->Release();

	if( Creater_Select != NULL )
        Creater_Select->Release();
 
    if( m_pSprite != NULL )
        m_pSprite->Release();

	return 0;
}

int CMainScreen::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	m_pd3dDevice = pd3dDevice; 
    D3DXCreateSprite(m_pd3dDevice, &m_pSprite );
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����ȭ��\\���.jpg",&MainScreen);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����ȭ��\\���ӽ���.png",&Start);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����ȭ��\\������.png",&Creater);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����ȭ��\\��������.png",&Quit);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����ȭ��\\creat.jpg",&Creater_Select);

	Music.LoadBGMFile(L"����\\BGM\\Bgm_Intro.mp3",Music.BGMDeviceID[BGM_INTRO]);
	Music.LoadEFTFile(L"����\\EFT\\Button_Move.mp3",Music.EFTDeviceID[Eft_BUTTON_MOVE]);
	Music.LoadEFTFile(L"����\\EFT\\Button_Sellect.mp3",Music.EFTDeviceID[Eft_BUTTON_SELLECT]);

	return 0;
}

int CMainScreen::Run(void)
{
	if(Bgm_Intro_Bool == false)
	{
		Music.PlayBGM(Music.BGMDeviceID[BGM_INTRO]);
		Bgm_Intro_Bool = true;
	}
	Draw();
	return 0;
}

int CMainScreen::Draw(void)
{
    // ��������Ʈ ������ ����
    if( SUCCEEDED( m_pSprite->Begin(D3DXSPRITE_ALPHABLEND ) ) )
    {
		Start_Pos=D3DXVECTOR3(434,477,0);

		Creater_Pos=D3DXVECTOR3(452,530,0);

		Quit_Pos=D3DXVECTOR3(473,584,0);

		Choice();

        // �׸���		
        m_pSprite->Draw(MainScreen, NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		if(Select == 0)
		{
			m_pSprite->Draw(Start, NULL, NULL,&Start_Pos, D3DCOLOR_XRGB(255,255,255));
		}
		else if(Select == 1)
		{
			m_pSprite->Draw(Creater, NULL, NULL,&Creater_Pos, D3DCOLOR_XRGB(255,255,255));
		}	
		else
		{
			m_pSprite->Draw(Quit, NULL, NULL,&Quit_Pos, D3DCOLOR_XRGB(255,255,255));
		}
		
        // ��������Ʈ ������ ����
        m_pSprite->End();
    }
	return 0;
}

int CMainScreen::CreateDraw(void)
{
    // ��������Ʈ ������ ����
    if( SUCCEEDED( m_pSprite->Begin(D3DXSPRITE_ALPHABLEND ) ) )
    {
		m_pSprite->Draw(Creater_Select, NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
        // ��������Ʈ ������ ����
        m_pSprite->End();
    }
	return 0;
}

void CMainScreen::Choice(void)
{	
	if(GetAsyncKeyState(VK_UP)& 0x0001)
	{
		Music.PlayEFT(Music.EFTDeviceID[Eft_BUTTON_MOVE]);
		Select -= 1;
	}
	if(GetAsyncKeyState(VK_DOWN)& 0x0001)
	{
		Music.PlayEFT(Music.EFTDeviceID[Eft_BUTTON_MOVE]);
		Select += 1;
	}
	if(Select>2)
	{
		Select = 2;
	}
	if(Select<0)
	{
		Select = 0;
	}
}

int CMainScreen::Change(void)
{
		Choice();
		if(Select == 0)
		{
			if(GetAsyncKeyState(VK_RETURN))
			{
				Music.PlayEFT(Music.EFTDeviceID[Eft_BUTTON_SELLECT]);
				Music.StopBGM(Music.BGMDeviceID[BGM_INTRO]);
				return 3; // ���������� �Ѿ��.
			}
		}
		if(Select == 1)
		{
			if(GetAsyncKeyState(VK_RETURN)& 0x0001)
			{
				Music.PlayEFT(Music.EFTDeviceID[Eft_BUTTON_SELLECT]);
				return 1;
			}
		}
		else if(Select == 2)
		{
			if(GetAsyncKeyState(VK_RETURN)& 0x0001)
			{
				Music.PlayEFT(Music.EFTDeviceID[Eft_BUTTON_SELLECT]);
				return 2;
			}
		}
		return 0;
}

