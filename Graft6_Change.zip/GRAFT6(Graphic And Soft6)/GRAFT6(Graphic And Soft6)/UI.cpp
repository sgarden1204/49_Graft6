#include "Ui.h"

CUi::CUi(void)
: Key_A_CoolTime_Control(0)
, Key_S_CoolTime_Control(0)
, Key_D_CoolTime_Control(0)
, Key_Space_CoolTime_Control(0)
, HealthPoint_Control(0)
{
	// UI(Ʋ,ü��,����)
	m_Whole_vPos.x=0;
	m_Whole_vPos.y=512;

	m_Hp_back_vPos.x=0;
	m_Hp_back_vPos.y=640;

	m_Mp_back_vPos.x=505;
	m_Mp_back_vPos.y=640;

	m_Hp_front_vPos.x=0;
	m_Hp_front_vPos.y=640;

	m_Mp_front_vPos.x=505;
	m_Mp_front_vPos.y=640;

	// ��ų(1,2,3,4,5)
	Skill_vPos.x=125;
	Skill_vPos.y=695;

	Skill2_vPos.x=198;
	Skill2_vPos.y=695;

	Skill3_vPos.x=271;
	Skill3_vPos.y=695;

	Skill4_vPos.x=345;
	Skill4_vPos.y=695;

	Skill5_vPos.x=419;
	Skill5_vPos.y=695;

}

CUi::~CUi(void)
{
}

int CUi::Exit(void)
{
	if( Whole != NULL )
        Whole->Release();

	if( Hp_front != NULL )
        Hp_front->Release();

	if( Hp_back != NULL )
        Hp_back->Release();

	if( Mp_front != NULL )
        Mp_front->Release();

	if( Mp_back != NULL )
        Mp_back->Release();

	if( Skill_On != NULL )
        Skill_On->Release();

	if( Skill2_On != NULL )
        Skill2_On->Release();

	if( Skill3_On != NULL )
        Skill3_On->Release();

	if( Skill4_On != NULL )
        Skill4_On->Release();

	if( Skill5_On != NULL )
        Skill5_On->Release();

	if( Skill_Off != NULL )
        Skill_Off->Release();

	if( Skill2_Off != NULL )
        Skill2_Off->Release();

	if( Skill3_Off != NULL )
        Skill3_Off->Release();

	if( Skill4_Off != NULL )
        Skill4_Off->Release();

	if( Skill5_Off != NULL )
        Skill5_Off->Release();

    if( m_pSprite != NULL )
        m_pSprite->Release();
	return 0;
}
int CUi::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	m_pd3dDevice = pd3dDevice;
	D3DXCreateSprite( m_pd3dDevice, &m_pSprite );
	//UI(Ʋ,ü��,����)
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\whole.png",&Whole);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Hp_front.png",&Hp_front);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Hp_back.png",&Hp_back);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Mp_front.png",&Mp_front);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Mp_back.png",&Mp_back);

	//��ų(1,2,3,4,5)
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill1_on.png",&Skill_On);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill2_on.png",&Skill2_On);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill3_on.png",&Skill3_On);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill4_on.png",&Skill4_On);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill5_on.png",&Skill5_On);

	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill1_off.png",&Skill_Off);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill2_off.png",&Skill2_Off);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill3_off.png",&Skill3_Off);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill4_off.png",&Skill4_Off);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"UI\\Skill\\Skill5_off.png",&Skill5_Off);


	return 0;
}

int CUi::Run(void)
{
	EnergyControl();
	HpControl();
	Draw();
	return 0;
}

int CUi::Draw(void)
{
        // ��������Ʈ ������ ����
        if( SUCCEEDED( m_pSprite->Begin(D3DXSPRITE_ALPHABLEND ) ) )
        {
			// �׸���
			// UIâ
            m_pSprite->Draw(Hp_back, NULL, NULL,&m_Hp_back_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Mp_back, NULL, NULL,&m_Mp_back_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Mp_front, &m_Mp_front_rect, NULL,&m_Mp_front_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Hp_front, &m_Hp_front_rect, NULL,&m_Hp_front_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Whole, NULL, NULL,&m_Whole_vPos, D3DCOLOR_XRGB(255,255,255));

			//��ų�� off
			m_pSprite->Draw(Skill_Off, NULL, NULL,&Skill_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill2_Off, NULL, NULL,&Skill2_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill3_Off, NULL, NULL,&Skill3_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill4_Off, NULL, NULL,&Skill4_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill5_Off, NULL, NULL,&Skill5_vPos, D3DCOLOR_XRGB(255,255,255));
			
			//��ų�� On
			Key_A_CoolTime();
			Key_S_CoolTime();
			Key_D_CoolTime();
			Key_Space_CoolTime();
			m_pSprite->Draw(Skill_On, &Key_A_CoolTime_rect, NULL,&Skill_On_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill2_On, &Key_S_CoolTime_rect, NULL,&Skill2_On_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill3_On, &Key_D_CoolTime_rect, NULL,&Skill3_On_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill4_On, &Key_Space_CoolTime_rect, NULL,&Skill4_On_vPos, D3DCOLOR_XRGB(255,255,255));
			m_pSprite->Draw(Skill5_On, NULL, NULL,&Skill5_vPos, D3DCOLOR_XRGB(255,255,255));
			
			// ��������Ʈ ������ ����
            m_pSprite->End();
        }
	return 0;
}

int CUi::HpControl(void)
{
	m_Hp_front_rect.left=0;
	m_Hp_front_rect.right=128;
	m_Hp_front_rect.top=HealthPoint_Control;
	m_Hp_front_rect.bottom=128;

	m_Hp_front_vPos.x = 0;
	m_Hp_front_vPos.y = 640+HealthPoint_Control;

	if(HealthPoint_Control < 29) // MP MAX�϶��� Y��
	{
		HealthPoint_Control = 29;
	}
	else if(HealthPoint_Control > 116) // MP MIX�϶��� Y��
	{
		HealthPoint_Control = 116;
	}
	else
	{
		HealthPoint_Control -=0.07;
	}
	return 0;
}

int CUi::HealthPoint_Decrease(float Hp)
{
	HealthPoint_Control += Hp;
	return 0;
}

int CUi::EnergyControl(void)
{
	m_Mp_front_rect.left=0;
	m_Mp_front_rect.right=128;
	m_Mp_front_rect.top=MpControl;
	m_Mp_front_rect.bottom=128;

	m_Mp_front_vPos.x = 505;
	m_Mp_front_vPos.y = 640+MpControl;

	if(MpControl < 29) // MP MAX�϶��� Y��
	{
		MpControl = 29;
	}
	else if(MpControl > 116) // MP MIX�϶��� Y��
	{
		MpControl = 116;
	}
	else
	{
		MpControl -=0.07;
	}
	return 0;
}

int CUi::Key_A(void)
{
	if(MpControl < 111)
	{	
		Key_A_CoolTime_Control = 64;
		MpControl += 5;		
	}
	return 0;
}

int CUi::Key_S(void)
{
	if(MpControl < 106)
	{
		Key_S_CoolTime_Control = 64;
		MpControl += 10;
	}
	return 0;
}

int CUi::Key_D(void)
{
	if(MpControl < 101)
	{
		Key_D_CoolTime_Control = 64;
		MpControl += 15;
	}
	return 0;
}

int CUi::Key_SPACE(void)
{
	if(MpControl < 96)
	{
		Key_Space_CoolTime_Control = 64;
		MpControl += 20;
	}
	return 0;
}

int CUi::Key_A_CoolTime(void)
{
	Key_A_CoolTime_rect.left = 0;
	Key_A_CoolTime_rect.right = 64;
	Key_A_CoolTime_rect.top = 0+Key_A_CoolTime_Control;
	Key_A_CoolTime_rect.bottom = 64;

	Skill_On_vPos.x = 125;
	Skill_On_vPos.y = 695+(int)Key_A_CoolTime_Control;

	if(Key_A_CoolTime_Control<0)
	{
		Key_A_CoolTime_Control=0;
	}
	if(Key_A_CoolTime_Control==0)
	{
		return 1;
	}
	else
	{
		Key_A_CoolTime_Control -= 1;
	}
	return 0;
}

int CUi::Key_S_CoolTime(void)
{
	Key_S_CoolTime_rect.left = 0;
	Key_S_CoolTime_rect.right = 64;
	Key_S_CoolTime_rect.top = 0+Key_S_CoolTime_Control;
	Key_S_CoolTime_rect.bottom = 64;

	Skill2_On_vPos.x = 198;
	Skill2_On_vPos.y = 695+(int)Key_S_CoolTime_Control;

	if(Key_S_CoolTime_Control<0)
	{
		Key_S_CoolTime_Control=0;
	}
	if(Key_S_CoolTime_Control==0)
	{
		return 1;
	}
	else
	{
		Key_S_CoolTime_Control -= 0.7;
	}
	return 0;
}

int CUi::Key_D_CoolTime(void)
{
	Key_D_CoolTime_rect.left = 0;
	Key_D_CoolTime_rect.right = 64;
	Key_D_CoolTime_rect.top = 0+Key_D_CoolTime_Control;
	Key_D_CoolTime_rect.bottom = 64;

	Skill3_On_vPos.x = 271;
	Skill3_On_vPos.y = 695+(int)Key_D_CoolTime_Control;

	if(Key_D_CoolTime_Control<0)
	{
		Key_D_CoolTime_Control=0;
	}
	if(Key_D_CoolTime_Control==0)
	{
		return 1;
	}
	else
	{
		Key_D_CoolTime_Control -= 0.5;
	}
	return 0;
}

int CUi::Key_Space_CoolTime(void)
{
	Key_Space_CoolTime_rect.left = 0;
	Key_Space_CoolTime_rect.right = 64;
	Key_Space_CoolTime_rect.top = 0+Key_Space_CoolTime_Control;
	Key_Space_CoolTime_rect.bottom = 64;

	Skill4_On_vPos.x = 345;
	Skill4_On_vPos.y = 695+(int)Key_Space_CoolTime_Control;

	if(Key_Space_CoolTime_Control<0)
	{
		Key_Space_CoolTime_Control=0;
	}
	if(Key_Space_CoolTime_Control==0)
	{
		return 1;
	}
	else
	{
		Key_Space_CoolTime_Control -= 0.3;
	}
	return 0;
}
