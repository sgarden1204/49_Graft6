#pragma once
#include "Defines.h"

class CGame
{
private:
public:
	LPDIRECT3D9 m_pD3D;
	LPDIRECT3DDEVICE9 m_pd3dDevice;
	CGame(void);
	~CGame(void);
	int Init(HWND hWnd);
	int Main(void);
	int Exit(void);
	int Draw(void);
	int GameState;
};
