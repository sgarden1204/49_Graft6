#pragma once
#include "Defines.h"

class CText
{
private:
	ID3DXFont			*Font_49;
	LPD3DXSPRITE		m_pSprite;

	LPDIRECT3DDEVICE9	m_pd3dDevice_Text;
	LPDIRECT3DDEVICE9	m_pd3dDevice_Images;

	RECT				m_Text_Rect;
	
	LPDIRECT3DTEXTURE9	m_Texture_Ari;
	LPDIRECT3DTEXTURE9	m_Texture_Secretary;
	LPDIRECT3DTEXTURE9	m_Texture_Kimdoujin;

	RECT				m_Images_Rect;
	D3DXVECTOR3			m_vPos_Images;


public:

	void Init_Text(LPDIRECT3DDEVICE9	Device);
	void Init_Images(LPDIRECT3DDEVICE9	Device);
	void Draw();
	void Exit();
	void Run();

	void Ari_Draw();
	void Secretary_Draw();
	void Kimdoujin_Draw();

	void mText(LPCWSTR Str);
	void TextR(LPCWSTR Str);

	void TextCombination();

	CText(void);
	~CText(void);
};
