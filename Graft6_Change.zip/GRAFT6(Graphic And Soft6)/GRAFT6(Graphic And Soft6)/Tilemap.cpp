#include "Tilemap.h"
#include "Defines.h"


int Firemap[TileHeight_Num][TileWidth_Num] =
								{	{41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*50*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*60*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*70*/, 41, 42, 43, 43, 43, 43, 44, 41, 41, 41/*80*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*90*/, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*100*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*110*/ , 41, 41, 41, 41, 41, 41, 41, 42, 43, 43  /*120*/, 43, 43, 43, 43, 43, 43, 44, 41, 41, 41/*130*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*140*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 42 /*150*/ , 43, 43, 43, 43, 43, 43, 43, 43, 43, 43 /*160*/ , 43, 43, 44, 41, 41, 41, 41, 41, 41, 41 /*170*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*180*/ , 41, 41, 41, 41, 41},
									{41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*50*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*60*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*70*/, 41, 45, 46, 46, 46, 46, 47, 41, 41, 41/*80*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*90*/, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*100*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*110*/ , 41, 41, 41, 41, 41, 41, 41, 45, 46, 46 /*120*/, 46, 46, 46, 46, 46, 46, 47, 41, 41, 41/*130*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*140*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 45 /*150*/ , 46, 46, 46, 46, 46, 46, 46, 46, 46, 46 /*160*/ , 46, 46, 47, 41, 41, 41, 41, 41, 41, 41 /*170*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*180*/ , 41, 41, 41, 41, 41},
									{41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*50*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*60*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*70*/, 41, 48, 49, 49, 49, 49, 50, 41, 41, 41/*80*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41/*90*/, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*100*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*110*/ , 41, 41, 41, 41, 41, 41, 41, 48, 49, 49 /*120*/, 49, 49, 49, 49, 49, 49, 50, 41, 41, 41/*130*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*140*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 48 /*150*/ , 49, 49, 49, 49, 49, 49, 49, 49, 49, 49 /*160*/ , 49, 49, 50, 41, 41, 41, 41, 41, 41, 41 /*170*/ , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*180*/ , 41, 41, 41, 41, 41}, 
									{0, 0, 0, 0, 0, 0, 5, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41, 7, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0,1, 0,1, 0, 1, 0, 1, 0 /*50*/ ,0, 20, 8, 8, 8, 8, 8, 8 , 8, 8 /*60*/ , 8, 8, 8, 8, 8, 32, 1, 0, 1, 0/*70*/, 1, 51, 52, 52, 52, 52, 53, 0, 1, 0/*80*/ ,0, 5, 41, 41, 41, 41, 41, 41, 41, 41/*90*/, 41, 41, 41, 41, 41, 41, 41, 41, 41, 41,/*100*/ 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*110*/ , 41, 41, 41, 41, 41, 7, 0, 51, 52, 52 /*120*/, 52, 52, 52, 52, 52, 52, 53, 1, 1, 0/*130*/ , 1, 0, 1, 0, 1, 0, 0, 1, 0, 0/*140*/, 1, 0, 1, 0, 1, 1, 0, 0, 0, 51 /*150*/ , 52, 52, 52, 52, 52, 52, 52, 52, 52, 52 /*160*/ , 52, 52, 53, 1, 1, 41, 41, 41, 41, 41 /*170*/  , 41, 41, 41, 41, 41, 41, 41, 41, 41, 41 /*180*/ , 41, 41, 41, 41, 41} ,
									{3, 2, 2, 2, 3, 3, 4, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 6, 21, 22, 22, 23, 2, 3, 2, 2, 3, 2, 3, 2, 3, 2, 2, 2, 2, 3, 2, 2 /*50*/ ,2, 55, 54, 54, 13, 13, 13, 13, 13, 13 /*60*/, 13, 13, 13, 13, 54, 56, 2, 9, 10, 10/*70*/, 10, 10, 10, 11, 3, 3, 2, 2, 2, 2/*80*/ , 2, 4, 1, 0, 1, 0, 1, 0, 1, 33 /*90*/ , 1, 34, 33, 0, 33, 0, 34, 0, 34, 0 /*100*/ , 1, 0, 0, 1, 0, 1, 0, 1, 0, 1 /*110*/ ,0, 0, 0, 0, 0, 6, 21, 22, 22, 22 /*120*/ , 23, 3, 2, 21, 22, 23, 2, 2, 3, 2 /*130*/ ,2, 2, 2, 2, 3, 2, 3, 2, 2, 3/*140*/, 2, 9, 10, 10, 11, 2, 3, 3, 3, 2 /*150*/ , 2, 3, 2, 3, 2, 3, 3, 2, 3, 3 /*160*/ , 3, 3, 2, 3, 2, 41, 41, 41, 41, 41 /*170*/ , 33, 34, 33, 34, 33, 0, 34, 1, 34, 33 /*180*/ , 34, 33, 34, 33, 34} ,
									{3, 3, 2, 3, 2, 2, 3, 2, 2, 3, 2, 3, 3, 2, 3, 2, 3, 3, 2, 3, 2, 2, 3, 3, 2, 2, 2, 3, 3, 2, 27, 28, 28, 29, 2, 2, 3, 21, 22, 22, 22, 23, 2, 2, 3, 2, 3, 2, 2, 3 /*50*/ ,3, 2, 3, 2, 2, 13, 13, 13, 13, 13 /*60*/, 13, 13, 13, 3, 3, 3, 2, 15, 16, 16/*70*/, 16, 16, 16, 17, 2, 2, 3, 2, 2, 2/*80*/ , 3, 2, 2, 3, 3, 2, 2, 3, 35, 2/*90*/ , 35, 35, 2, 35, 3, 35, 35, 35, 35, 35/*100*/ , 3, 3, 3, 2, 2, 3, 3, 2, 3, 3 /*110*/ , 2, 2, 3, 2, 2, 2, 27, 28, 28, 28 /*120*/ , 29, 2, 3, 24, 25, 30, 23, 2, 3, 2 /*130*/ , 3, 2, 3, 2, 2, 3, 2, 2, 2, 2/*140*/, 3, 15, 16, 16, 17, 3, 2, 3, 3, 2 /*150*/ , 2, 2, 3, 2, 3, 2, 3, 3, 2, 3 /*160*/ , 2, 2, 3, 2, 3, 2, 2, 35, 2, 35 /*170*/ , 35, 35, 2, 35, 35, 2, 35, 35, 3, 35 /*180*/ , 2, 3, 35, 3, 35},
									{3, 2, 2, 2, 3, 2, 2, 3, 2, 2, 2, 2, 2, 3, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 21, 22, 22, 23, 2, 2, 3, 2, 3, 2, 21, 31, 25, 25, 25, 26, 3, 2, 2, 2, 2, 2, 2, 2 /*50*/ ,2, 3, 2, 2, 2, 2, 13, 13, 3, 3 /*60*/, 13, 13, 3, 3, 3, 2, 3, 2, 3, 3/*70*/, 2, 2, 3, 2, 2, 2, 2, 2, 3, 2/*80*/ , 2, 2, 2, 2, 2, 3, 2, 2, 3, 35/*90*/ , 3, 35, 35, 3, 35, 3, 35, 35, 35, 3/*100*/ , 35, 3, 2, 3, 2, 2, 2, 2, 2, 2 /*110*/ , 3, 2, 2, 3, 3, 2, 3, 2, 2, 3 /*120*/ , 3, 21, 23, 27, 28, 28, 29, 2, 2, 3 /*130*/ , 2, 2, 2, 3, 3, 2, 3, 3, 2, 2/*140*/, 2, 3, 3, 3, 3, 3, 3, 3, 2, 3 /*150*/ , 2, 3, 2, 2, 3, 2, 2, 3, 2, 2 /*160*/ , 3, 2, 3, 3, 2, 35, 3, 35, 35, 35 /*170*/ , 35, 35, 35, 35, 3, 35, 3, 35, 35, 2 /*180*/ , 2, 35, 35, 35, 3},
									{3, 3, 2, 2, 2, 2, 3, 2, 2, 3, 2, 2, 2, 2, 9, 10, 10, 11, 2, 2, 3, 2, 3, 2, 2, 21, 31, 25, 25, 26, 2, 3, 2, 3, 2, 21, 31, 25, 25, 25, 25, 30, 23, 3, 2, 2, 2, 2, 2, 2 /*50*/ ,3, 3, 3, 2, 2, 13, 13, 13, 13, 13 /*60*/, 13, 13, 13, 3, 3, 2, 2, 3, 2, 2/*70*/, 3, 2, 2, 3, 2, 9, 10, 11, 2, 9/*80*/ , 10, 10, 10, 10, 11, 2, 2, 3, 2, 35/*90*/ , 35, 35, 35, 35, 3, 35, 3, 35, 35, 35/*100*/ , 3, 3, 2, 2, 2, 2, 2, 2, 3, 2 /*110*/ , 2, 3, 21, 22, 22, 23, 2, 2, 2, 21 /*120*/ , 22, 31, 26, 3, 2, 3, 2, 3, 2, 2 /*130*/ , 2, 2, 2, 2, 2, 3, 2, 3, 2, 2/*140*/, 3, 2, 3, 3, 3, 2, 2, 3, 3, 2 /*150*/ , 2, 2, 2, 2, 2, 3, 3, 2, 3, 3 /*160*/ , 2, 3, 2, 3, 2, 3, 3, 2, 2, 35 /*170*/ , 35, 3, 2, 35, 2, 2, 35, 35, 35, 3 /*180*/ , 35, 35, 3, 2, 35},
									{2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 3, 9, 19, 13, 13, 18, 10, 10, 11, 2, 2, 2, 3, 24, 25, 25, 25, 30, 22, 22, 23, 2, 2, 27, 28, 28, 28, 28, 28, 28, 29, 2, 2, 2, 2, 3, 2, 2 /*50*/ ,2, 2, 2, 3, 13, 13, 13, 13, 13, 13 /*60*/, 13, 13, 13, 13, 2, 3, 2, 2, 9, 11/*70*/, 2, 2, 2, 2, 2, 12, 13, 18, 10, 19/*80*/ , 13, 13, 13, 13, 14, 2, 2, 2, 2, 2/*90*/ , 3, 35, 3, 35, 2, 35, 35, 35, 35, 3/*100*/ , 35, 2, 3, 3, 2, 3, 2, 2, 2, 3 /*110*/ , 2, 2, 24, 25, 25, 30, 22, 23, 3, 27 /*120*/ , 28, 28, 29, 2, 21, 23, 2, 2, 2, 3 /*130*/ , 2, 2, 3, 2, 3, 9, 10, 10, 10, 11/*140*/, 2, 2, 3, 2, 2, 3, 9, 10, 10, 11 /*150*/ , 3, 3, 2, 3, 2, 3, 2, 3, 2, 3/*160*/ , 2, 2, 2, 2, 3, 2, 41, 41, 3, 2 /*170*/ , 35, 35, 2, 3, 2, 35, 2, 35, 2, 35 /*180*/ , 35, 2, 35, 35, 2},
									{2, 3, 2, 3, 3, 2, 3, 3, 2, 2, 3, 2, 3, 15, 16, 16, 16, 16, 16, 16, 17, 2, 3, 2, 3, 27, 28, 28, 28, 28, 28, 28, 29, 3, 2, 2, 2, 3, 2, 2, 3, 2, 2, 3, 2, 3, 2, 2, 3, 2 /*50*/ , 2, 2, 3, 2, 2, 13, 13, 13, 13, 13 /*60*/, 13, 13, 13, 3, 3, 2, 3, 2, 15, 18/*70*/, 11, 3, 2, 3, 9, 19, 13, 13, 13, 13/*80*/ , 13, 13, 13, 13, 14, 3, 3, 3, 2, 3/*90*/ , 3, 2, 35, 3, 35, 35, 3, 35, 2, 35/*100*/ , 3, 35, 3, 2, 2, 2, 2, 2, 3, 2 /*110*/ , 2, 21, 31, 25, 25, 25, 25, 30, 23, 2 /*120*/ , 3, 2, 2, 3, 27, 29, 2, 3, 2, 2 /*130*/ , 2, 2, 2, 2, 2, 15, 16, 13, 16, 18/*140*/, 11, 3, 2, 2, 3, 2, 12, 13, 13, 17 /*150*/ , 2, 2, 3, 2, 2, 2, 3, 3, 3, 2 /*160*/ , 3, 2, 3, 3, 2, 3, 41, 41, 41, 41 /*170*/ , 2, 2, 35, 2, 3, 2, 3, 35, 35, 3 /*180*/ , 35, 35, 2, 35, 2}
								};

CTilemap::CTilemap(void)
: mapPos(0)
, Ani_Num_FireFall(0)
, Ani_Num2(0)
, Bgm_Stage_Bool(false)
{
	RECT rect_ani = {0, 0, 50, 50};
	RECT rect_ani2 = {0, 0, 64, 64};
	RECT rect_ani3 = {0, 0, 50, 50};
}
CTilemap::~CTilemap(void)
{
}

int CTilemap::Exit(void)
{
	if( Stage1 != NULL )
		Stage1->Release();

	if( BG != NULL )
		BG->Release();
	
	if( Warp != NULL )
		Warp->Release();

	if( Object[0] != NULL )
		Object[0]->Release();

	if( Object[1] != NULL )
		Object[1]->Release();

	if( Object[2] != NULL )
		Object[2]->Release();

	if( Object[3] != NULL )
		Object[3]->Release();

	if( Object[4] != NULL )
		Object[4]->Release();

	if( Object_left != NULL )
		Object_left->Release();

	if( Object_center != NULL )
		Object_center->Release();

	if( Object_right != NULL )
		Object_right->Release();

	if( Object_up != NULL )
		Object_up->Release();

	if( Object_down != NULL )
		Object_down->Release();

	if( Fire_Ani[0] != NULL )
		Fire_Ani[0]->Release();

	if( Fire_Ani[1] != NULL )
		Fire_Ani[1]->Release();

    if( m_pSprite != NULL )
        m_pSprite->Release();

	return 0;
}

int CTilemap::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	m_pd3dDevice = pd3dDevice;
    D3DXCreateSprite(m_pd3dDevice, &m_pSprite);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\����4.png",&Stage1);

	D3DXCreateTextureFromFile(m_pd3dDevice,L"object\\Dston1.png",&Object[0]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"object\\Dston2.png",&Object[1]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"object\\õ��1.png",&Object[2]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"object\\õ��2.png",&Object[3]);

	D3DXCreateTextureFromFile(m_pd3dDevice,L"object\\lavafall.png",&Object[4]);

	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\��.png",&Object_left);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\�߾�.png",&Object_center);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\��.png",&Object_right);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\��.png",&Object_up);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\�Ʒ�.png",&Object_down);

	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\warp.png",&Warp);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\background.png",&BG);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\startwall.png",&Object_startwall);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\magma_ani.png",&Fire_Ani[0]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"fire\\lavafall_ani.png",&Fire_Ani[1]);

	Music.LoadBGMFile(L"����\\BGM\\Bgm_Stage.mp3",Music.BGMDeviceID[BGM_STAGE1]);

	return 0;
}

int CTilemap::Run(float p_mapPos)
{
	Draw(p_mapPos);
	return 0;
}

int CTilemap::Draw(float p_mapPos)
{
	if(Bgm_Stage_Bool==false)
	{
		Music.PlayBGM(Music.BGMDeviceID[BGM_STAGE1]);
		Bgm_Stage_Bool=true;
	}
	// ��������Ʈ ������ ����
    if( SUCCEEDED( m_pSprite->Begin(D3DXSPRITE_ALPHABLEND ) ) )
    {
		// �׸���
		BackgroundDraw(p_mapPos);
		TilemapDraw(p_mapPos);
		ObjectDraw(p_mapPos);
		FireFall_Animation(p_mapPos);

		// ��������Ʈ ������ ����
        m_pSprite->End();
    }
	return 0;
}

int CTilemap::DrawInit(LPD3DXSPRITE pSprite, LPDIRECT3DTEXTURE9 m_pTexture, RECT rect, D3DXVECTOR3 vPos)
{
	m_pSprite		= pSprite;
	m_Texture		= m_pTexture;
	m_rect			= rect;
	m_vPos			= vPos;
	return 0;
}

void CTilemap::GetTileRect(int index)
{
	m_rect .left  =0;
	m_rect .right =80;
	m_rect .top =0;
	m_rect .bottom =80;

	if(index >= 0 && index <= 2) // �� Ÿ�� 1~3��(���赵 ��)
	{
		m_rect .left	+= 80*index;
		m_rect .right	+= 80*index;
	}
	else if(index >= 3 && index <= 5) // �� Ÿ�� 4~6��(���赵 ��)
	{
		m_rect .left	+= 80*(index-3);
		m_rect .right	+= 80*(index-3);
		m_rect .top	+= 80;
		m_rect .bottom+= 80;
	}
	else if(index >= 6 && index <= 8) // �� Ÿ�� 7~8��(���赵 ��) / 9�� Ÿ���� ���
	{
		m_rect .left	+= 80*(index-6);
		m_rect .right	+= 80*(index-6);
		m_rect .top	+= 160;
		m_rect .bottom+= 160;
	}
	else if(index >= 9 && index <= 11) // ���� ��� Ÿ�� 1~3��(���赵 ��)
	{
		m_rect .left	+= 80*(index-9);
		m_rect .right	+= 80*(index-9);
		m_rect .top	+= 240;
		m_rect .bottom+= 240;
	}
	else if(index >= 12 && index <= 14) // ���� ��� Ÿ�� 4~6��(���赵 ��)
	{
		m_rect .left	+= 80*(index-12);
		m_rect .right	+= 80*(index-12);
		m_rect .top	+= 320;
		m_rect .bottom+= 320;
	}
	else if(index >= 15 && index <= 17) // ���� ��� Ÿ�� 7~9��(���赵 ��)
	{
		m_rect .left	+= 80*(index-15);
		m_rect .right	+=80*(index-15);;
		m_rect .top	+= 400;
		m_rect .bottom+=400;
	}
	else if(index >= 18 && index <= 20) // ���� ��� Ÿ�� 10~12��(���赵 ��)
	{
		m_rect .left	+= 80*(index-18);
		m_rect .right	+= 80*(index-18);
		m_rect .top	+= 480;
		m_rect .bottom+=480;
	}
	else if(index >= 21 && index <= 23) // ���� ��� Ÿ�� 1~3��(���赵 ��)
	{
		m_rect .left	+= 80*(index-21);
		m_rect .right	+= 80*(index-21);
		m_rect .top	+= 560;
		m_rect .bottom+=560;
	}
	else if(index >= 24 && index <= 26) // ���� ��� Ÿ�� 4~6��(���赵 ��)
	{
		m_rect .left	+= 80*(index-24);
		m_rect .right	+= 80*(index-24);
		m_rect .top	+= 640;
		m_rect .bottom+=640;
	}
	else if(index >= 27 && index <= 29) // ���� ��� Ÿ�� 7~9��(���赵 ��)
	{
		m_rect .left	+= 80*(index-27);
		m_rect .right	+= 80*(index-27);
		m_rect .top	+= 720;
		m_rect .bottom+=720;
	}
	else if(index >= 30 && index <= 32) // ���� ��� Ÿ�� 10~12��(���赵 ��)
	{
		m_rect .left	+= 80*(index-30);
		m_rect .right	+= 80*(index-30);
		m_rect .top	+= 800;
		m_rect .bottom+=800;
	}
	else if(index >= 33 && index <= 35) // ������ ��� �� Ÿ�� 1~3��
	{
		m_rect .left	+= 80*(index-33);
		m_rect .right	+= 80*(index-33);
		m_rect .top	+= 880;
		m_rect .bottom+=880;
	}
	else if(index >= 36 && index <= 38) // ������ ��� �� Ÿ�� 4~6��
	{
		m_rect .left	+= 80*(index-36);
		m_rect .right	+= 80*(index-36);
		m_rect .top	+= 960;
		m_rect .bottom+=960;
	}
	else if(index >= 39 && index <= 41) // ������ ��� �� Ÿ�� 7~8�� // Ÿ�� 9��(41�� Ÿ��)�� ��ĭ
	{
		m_rect .left	+= 80*(index-39);
		m_rect .right	+= 80*(index-39);
		m_rect .top	+= 1040;
		m_rect .bottom+=1040;
	}
	else if(index >= 42 && index <= 44) // �� Ÿ�� 1~3��
	{
		m_rect .left	+= 80*(index-42);
		m_rect .right	+= 80*(index-42);
		m_rect .top	+= 1120;
		m_rect .bottom+= 1120;
	}
	else if(index >= 45 && index <= 47) // �� Ÿ�� 4~6��
	{
		m_rect .left	+= 80*(index-45);
		m_rect .right	+= 80*(index-45);
		m_rect .top	+= 1200;
		m_rect .bottom+= 1200;
	}
	else if(index >= 48 && index <= 50) // �� Ÿ�� 7~9��
	{
		m_rect .left	+= 80*(index-48);
		m_rect .right	+= 80*(index-48);
		m_rect .top	+= 1280;
		m_rect .bottom+= 1280;
	}
	else if(index >= 51 && index <= 53) // �� Ÿ�� 10~12��
	{
		m_rect .left	+= 80*(index-51);
		m_rect .right	+= 80*(index-51);
		m_rect .top	+= 1360;
		m_rect .bottom+= 1360;
	}
	else if(index >= 54 && index <= 56) // ���+�� Ÿ��
	{
		m_rect .left	+= 80*(index-54);
		m_rect .right	+= 80*(index-54);
		m_rect .top	+= 1440;
		m_rect .bottom+= 1440;
	}

}

void CTilemap::TilemapDraw(float p_mapPos)
{
	int (*map)[TileHeight_Num][TileWidth_Num];

	for(int i =0; i<TileHeight_Num; i++)
	{
		for( int j =0; j<TileWidth_Num; j++)
		{
			map = &Firemap;
			GetTileRect((*map)[i][j]);
			DrawInit(m_pSprite,Stage1,m_rect,D3DXVECTOR3((float)80*j, (float)80*i, 0));
			mapPos = (int)p_mapPos;
			m_vPos.x += mapPos;
			m_pSprite->Draw(Stage1, &m_rect, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		}
	}

	Fire_Animation2(p_mapPos);
		// ���� ��� 1
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1140, 670, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1180, 580, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1350, 580, 0)); //7
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1540, 680, 0)); //9
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ��� ���
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(4400, 250, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(4500, 600, 0)); //5
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(4600, 360, 0)); //6
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(4800, 550, 0)); //8
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(4900, 360, 0)); //10
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 2 ��
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(5400, 340, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(5530, 380, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(5650, 400, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(5800, 370, 0)); //6
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 3
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(6070, 600, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(6100, 620, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(6320, 650, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(6600, 610, 0)); //7
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 4
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(10850, 700, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(11050, 660, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 5
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(11350, 390, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(11450, 340, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 6
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(11700, 650, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(11820, 690, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	Fire_Animation(p_mapPos);
	
		// ���� ��� 1
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1100, 700, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1200, 600, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1250, 660, 0)); //5
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1300, 640, 0)); //6
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1480, 650, 0)); //8
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ��� ���
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(4300, 290, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(4450, 280, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));	
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(4500, 380, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(4700, 400, 0)); //7
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(4840, 620, 0)); //9
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ������� 2 �Ʒ�
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(5500, 650, 0));
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(5600, 720, 0));
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// �������2 ��
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(5440, 360, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(5700, 350, 0)); //5
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 3
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(6200, 670, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(6400, 690, 0)); //5
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(6460, 590, 0)); //6
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(6640, 640, 0)); //8
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 4
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(10890, 670, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(11000, 640, 0)); //3
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 5
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(11300, 360, 0)); //1
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(11490, 370, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		// ���� ��� 6
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(11720, 670, 0)); //2
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(11900, 660, 0)); //4
		m_vPos.x+=mapPos;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

}
void CTilemap::BackgroundDraw(float p_mapPos)
{
	RECT rect_bg = {0, 0, 14800, 1024};
	DrawInit(m_pSprite,BG,rect_bg,D3DXVECTOR3(0, 0, 0));
	mapPos = (int)p_mapPos;
	m_vPos.x += mapPos/5.5;
	m_pSprite->Draw(BG, &rect_bg, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	Fire_Animation(p_mapPos);
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(250, 250, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(300, 280, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(560, 220, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(700, 180, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(920, 210, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1000, 230, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1300, 250, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1350, 200, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani,D3DXVECTOR3(1380, 240, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	Fire_Animation2(p_mapPos);

		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(450, 250, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(470, 300, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(540, 320, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(740, 280, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(850, 200, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(600, 230, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1200, 270, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1300, 250, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
		DrawInit(m_pSprite,Fire_Ani[0],rect_ani3,D3DXVECTOR3(1410, 230, 0));
		m_vPos.x+=mapPos/5.5;
		m_pSprite->Draw(Fire_Ani[0], &rect_ani3, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
}

int CTilemap::TilemapScroll(float p_mapPos)
{
	if(p_mapPos > 500) // ĳ������ ��ǥ�� 700�̻��� �ɶ�
	{
		int move = (int)p_mapPos-500; // ĳ������ ��ǥ������ 700 �� ���ذ��� move(���� �̵��� ��ŭ�� ��)�� �������ش�.
		mapPos -= move;	// ���� ��ǥ���� move ����ŭ �̵���Ų��.

		if(mapPos < (- 13775)) // ���� ������ ������ ���� �׸� �̵�
		{
			mapPos += move;
			return mapPos;
		}
		return mapPos;
	}
	else if(p_mapPos < 200) // ĳ������ ��ǥ�� 100���ϰ� �ɶ�
	{
		int move = 200-(int)p_mapPos; // ĳ������ ��ǥ���� move(���� �̵��� ��ŭ�� ��)�� �������ش�.
		mapPos += move; // ���� ��ǥ���� move ����ŭ �̵���Ų��.
		
		if(mapPos>0) // ���� ���� ������ ���� �׸� �̵�
		{
			mapPos -= move;
			return mapPos;
		}
		return mapPos;
	}
	return mapPos;
}

int CTilemap::TileMoveable()
{
	int (*map)[TileHeight_Num][TileWidth_Num];

	for(int i =0; i<TileHeight_Num; i++)
	{
		for( int j =0; j<TileWidth_Num; j++)
		{
			map = &Firemap;
			if((*map)[i][j] >= 9 && (*map)[i][j] <= 19) // ���� ��� Ÿ�� (�̵��Ұ�)
			{
				//m_vPos.x;
				return m_vPos.x;
			}
			return 0;
		}
	}

}
////----------------------------------- �ִϸ��̼�
void CTilemap::Fire_Animation(float p_mapPos)
{
	Ani_Delay++;

	if(Ani_Delay == 50)
	{
		Ani_Delay = 0;

		if(Ani_Num == 0)
		{
			rect_ani.left = 0;
			rect_ani.right = 50;
			rect_ani.top = 0;
			rect_ani.bottom = 50;
			Ani_Num++;
		}
		else if(0<Ani_Num && Ani_Num < 7)
		{
			rect_ani.left += 50;
			rect_ani.right += 50;
			rect_ani.top = 0;
			rect_ani.bottom = 50;
			Ani_Num++;
		}
		else
		{
			Ani_Num = 0;
		}
	}
}
void CTilemap::Fire_Animation2(float p_mapPos) // ��� �ִϸ��̼�
{
	Ani_Delay2++;

	if(Ani_Delay2 == 55)
	{
		Ani_Delay2 = 0;

		if(Ani_Num2 == 0)
		{
			rect_ani3.left = 0;
			rect_ani3.right = 50;
			rect_ani3.top = 0;
			rect_ani3.bottom = 50;
			Ani_Num2++;
		}
		else if(0<Ani_Num2 && Ani_Num2 < 7)
		{
			rect_ani3.left += 50;
			rect_ani3.right += 50;
			rect_ani3.top = 0;
			rect_ani3.bottom = 50;
			Ani_Num2++;
		}
		else
		{
			Ani_Num2 = 0;
		}
	}
}

void CTilemap::FireFall_Animation(float p_mapPos) // ���� �ִϸ��̼�
{

	Ani_Delay++;

	if(Ani_Delay == 2)
	{
		Ani_Delay = 0;

		if(Ani_Num_FireFall == 0)
		{
			rect_ani2.left = 0;
			rect_ani2.right = 64;
			rect_ani2.top = 0;
			rect_ani2.bottom = 64;
			Ani_Num_FireFall++;
		}
		else if(0<Ani_Num_FireFall && Ani_Num_FireFall < 6)
		{
			rect_ani2.left += 64;
			rect_ani2.right += 64;
			rect_ani2.top = 0;
			rect_ani2.bottom = 64;
			Ani_Num_FireFall++;
		}
		else
		{
			Ani_Num_FireFall = 0;
		}
	}

	DrawInit(m_pSprite,Fire_Ani[1],rect_ani2,D3DXVECTOR3(4550, 30, 0));
	m_vPos.x+=mapPos;
	m_pSprite->Draw(Fire_Ani[1], &rect_ani2, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	DrawInit(m_pSprite,Fire_Ani[1],rect_ani2,D3DXVECTOR3(4829, 18, 0));
	m_vPos.x+=mapPos;
	m_pSprite->Draw(Fire_Ani[1], &rect_ani2, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	DrawInit(m_pSprite,Fire_Ani[1],rect_ani2,D3DXVECTOR3(4763, 150, 0));
	m_vPos.x+=mapPos;
	m_pSprite->Draw(Fire_Ani[1], &rect_ani2, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	DrawInit(m_pSprite,Fire_Ani[1],rect_ani2,D3DXVECTOR3(4870, 140, 0));
	m_vPos.x+=mapPos;
	m_pSprite->Draw(Fire_Ani[1], &rect_ani2, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	DrawInit(m_pSprite,Fire_Ani[1],rect_ani2,D3DXVECTOR3(4587, 226, 0));
	m_vPos.x+=mapPos;
	m_pSprite->Draw(Fire_Ani[1], &rect_ani2, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

}

////----------------------------------- ������Ʈ
void CTilemap::ObjectDraw(float b)
{

	RECT rect_bottom = {0, 0, 128, 128}; // �ٴ� ������Ʈ ũ��
	RECT rect_top = {0, 0, 512, 256}; // õ�� ������Ʈ ũ��
	RECT rect_waterfall = {0, 0, 464, 316}; // ���� ũ��
	mapPos = (int)b; // ��ũ�� �Լ����� ��ȯ�Ǵ� �� ��ŭ ������ �ش�.
	
	////--------------------- ���� ��
	RECT rect_start = {0, 0, 512, 512};
	DrawInit(m_pSprite,Object_startwall, rect_start,D3DXVECTOR3(0, 0, 0));
	m_vPos.x += mapPos;	 // ��ũ�� �Լ����� ��ȯ�Ǵ� �� ��ŭ ������ �ش�.
	m_pSprite->Draw(Object_startwall, &rect_start, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	////----------------------- �ٴ�1 (Object[0]) 
	//------ 0
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(0, 250, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 1
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(500, 600, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 2
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(1100, 320, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 3
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(1450, 360, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 4
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(1700, 360, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 5
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(3600, 260, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 6
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(4000, 480, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 7
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(4200, 320, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 8
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(7200, 500, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 9
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(7300, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 10
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(7600, 400, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 11
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(7850, 350, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 12
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(8860, 530, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 13
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(9100, 480, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 14
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(9500, 430, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 15
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(10600, 540, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 16
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(10700, 600, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 17
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(11200, 540, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 18
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(11600, 240, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 19
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(12000, 350, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 20
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(12300, 420, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 21
	DrawInit(m_pSprite,Object[0], rect_bottom,D3DXVECTOR3(11900, 480, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[0],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));


	////----------------------- �ٴ�2 (Object[1]) 
	//0
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(500, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 1
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(1200, 380, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 2
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(1600, 450, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 3
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(2600, 640, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 4
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(2950, 320, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 5
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(3800, 560, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 6
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(4100, 260, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 7
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(7100, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 8
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(7350, 550, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 9
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(7400, 340, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 10
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(7700, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 11
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(7800, 600, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 12
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(8000, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 13
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(9250, 530, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 14
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(9700, 240, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 15
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(10100, 560, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 16
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(10700, 300, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 17
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(10800, 250, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 18
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(11000, 370, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 19
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(11500, 600, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 20
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(11800, 200, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));
	//------ 21
	DrawInit(m_pSprite,Object[1], rect_bottom,D3DXVECTOR3(12400, 230, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[1],&rect_bottom, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	//////------------------ ���� (Object[4]) 
	DrawInit(m_pSprite,Object[4], rect_waterfall,D3DXVECTOR3(4500, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[4],&rect_waterfall, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	////------------------- õ��1 (Object[2]) 
	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(1500, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(5000, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(6700, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(8200, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(8900, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[2], rect_top,D3DXVECTOR3(12000, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[2],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));


	////------------------- õ��2 (Object[3]) 
	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(700, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(2000, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(3600, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(5600, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(7500, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object[3], rect_top,D3DXVECTOR3(10000, 0, 0));		
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object[3],&rect_top, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	////------------------------- ���� ����� ��
	RECT rect_leftright = {0, 0, 256, 512};
	RECT rect_center = {0, 0, 256, 256};
	RECT rect_updown = {0, 0, 512, 256};

	DrawInit(m_pSprite,Object_left, rect_leftright,D3DXVECTOR3(4310, 290, 0));		// ��
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object_left,&rect_leftright, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object_center, rect_center,D3DXVECTOR3(4590, 450, 0));		// �߾�
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object_center,&rect_center, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object_right, rect_leftright,D3DXVECTOR3(4865, 290, 0));		// ��
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object_right,&rect_leftright, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object_up, rect_updown,D3DXVECTOR3(13200, 145, 0));		// ��
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object_up,&rect_updown, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	DrawInit(m_pSprite,Object_down, rect_updown,D3DXVECTOR3(13200, 600, 0));		// �Ʒ�
	m_vPos.x += mapPos;	
	m_pSprite->Draw(Object_down,&rect_updown, NULL,&m_vPos, D3DCOLOR_XRGB(255,255,255));

	////--------------------- ����
	Warp_Pos=D3DXVECTOR3(5100, 420, 0);
	RECT rect_w = {0, 0, 128, 128};
	Warp_Pos.x += mapPos;	 // ��ũ�� �Լ����� ��ȯ�Ǵ� �� ��ŭ ������ �ش�.
	m_pSprite->Draw(Warp, &rect_w, NULL,&Warp_Pos, D3DCOLOR_XRGB(255,255,255));

}

int CTilemap::Boss_Choice(float x, float y)
{
	if(x + 256 > Warp_Pos.x && x < Warp_Pos.x+128 && y+256> Warp_Pos.y && y+256<Warp_Pos.y + 128 )
	{
		if( GetAsyncKeyState(VK_RETURN)& 0x8000)
		{

			Music.StopBGM(Music.BGMDeviceID[BGM_STAGE1]);
			return 9; // CGame�� GameState�� ���� 5�� �������ش�.
		}
	}
	return 8; // ������ �������� ���� �� GameState�� ���� 4���� �������ش�.
}
