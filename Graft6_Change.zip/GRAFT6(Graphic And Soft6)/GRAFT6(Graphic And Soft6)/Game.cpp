#include "Game.h"
#include "MainScreen.h"
#include "Character.h"
#include "Tilemap.h"
#include "Boss.h"
#include "Guardian.h"
#include "FireFox.h"
#include "FireGhost.h"
#include "Opening.h"
#include "ChogangKing.h"
#include "Hospital.h"
#include "Accident.h"
#include "MoodangHouse.h"
#include "SamDoChun.h"
#include "Text.h"


// Ŭ���� ����
// ���� ȭ��
CMainScreen MainScreen;

// ������
COpening Opening;

// ĳ����
CCharacter	Character;

// ��
CTilemap	Tilemap;
CBoss Boss;
CHospital Hospital;
CAccident Accident;
CMoodangHouse MoodangHouse;
CSamDoChun SamDoChun;

// ����
CGuardian	Guardian;
CGuardian	GuardianArr[3];

CFireFox	FireFox;
CFireFox	FireFox2;
CFireFox	FireFox3;
CFireFox	FireFox4;
CFireFox	FireFox5;
CFireFox	FireFox6;
CFireFox	FireFox7;

CFireGhost	FireGhost;
CFireGhost	FireGhost2;
CFireGhost	FireGhost3;
CFireGhost	FireGhost4;
CFireGhost	FireGhost5;
CFireGhost	FireGhost6;
CFireGhost	FireGhost7;

CChogangKing	ChogangKing;

CText			Text;

CGame::CGame(void)
{
}

CGame::~CGame(void)
{
}

int CGame::Init(HWND hWnd)
{
	// ����̽��� �����ϱ� ���� D3D ��ü ����
	if(NULL == ( m_pD3D = Direct3DCreate9(D3D_SDK_VERSION)))
		return E_FAIL;

	D3DPRESENT_PARAMETERS d3dpp; // ����̽� ������ ���� ����ü
	ZeroMemory(&d3dpp,sizeof(d3dpp)); // ZeroMemory() �Լ��� �̿��Ͽ� �̸� ����ü�� �����ϰ� �����.

	d3dpp.Windowed = TRUE; // â��� ����
	d3dpp.BackBufferWidth = 1024;
	d3dpp.BackBufferHeight = 768; // �����
	d3dpp.SwapEffect = D3DSWAPEFFECT_DISCARD; // ���� ȿ������ SWAP ȿ��
	d3dpp.BackBufferFormat = D3DFMT_UNKNOWN; // ���� ����ȭ�� ��忡 ���缭 �ĸ� ���� ����

	// ����̽� �����Ѵ�.
    if( FAILED( m_pD3D->CreateDevice( D3DADAPTER_DEFAULT, D3DDEVTYPE_HAL, hWnd,
                                      D3DCREATE_SOFTWARE_VERTEXPROCESSING,
                                      &d3dpp, &m_pd3dDevice ) ) )
    {
        return E_FAIL;
    }
	// ����̽� ���� ������ ó���� �ܿ� �� �ּ� �ؿ��� �Ѵ�.

	MainScreen.Init(m_pd3dDevice);
	Opening.Init(m_pd3dDevice);	
	
	Character.Init(m_pd3dDevice);

	Tilemap.Init(m_pd3dDevice);
	Boss.Init(m_pd3dDevice);
	Hospital.Init(m_pd3dDevice);
	Accident.Init(m_pd3dDevice);
	MoodangHouse.Init(m_pd3dDevice);
	SamDoChun.Init(m_pd3dDevice);

	Text.Init_Images(m_pd3dDevice);
	Text.Init_Text(m_pd3dDevice);

	Guardian.Init(m_pd3dDevice);

	FireFox.Init(m_pd3dDevice);
	FireFox2.Init(m_pd3dDevice);
	FireFox3.Init(m_pd3dDevice);
	FireFox4.Init(m_pd3dDevice);
	FireFox5.Init(m_pd3dDevice);
	FireFox6.Init(m_pd3dDevice);
	FireFox7.Init(m_pd3dDevice);

	FireGhost.Init(m_pd3dDevice);
	FireGhost2.Init(m_pd3dDevice);
	FireGhost3.Init(m_pd3dDevice);
	FireGhost4.Init(m_pd3dDevice);
	FireGhost5.Init(m_pd3dDevice);
	FireGhost6.Init(m_pd3dDevice);
	FireGhost7.Init(m_pd3dDevice);


	//���� �ʱ�ȭ ��ǥ��

	FireFox.Monster_vPos.x = 2300.0f;
	FireFox.Monster_vPos.y = 260.0f;

	FireFox2.Monster_vPos.x = 3500.0f;
	FireFox2.Monster_vPos.y = 280.0f;

	FireFox3.Monster_vPos.x = 4200.0f;
	FireFox3.Monster_vPos.y = 430.0f;

	FireFox4.Monster_vPos.x = 7000.0f;
	FireFox4.Monster_vPos.y = 300.0f;

	FireFox5.Monster_vPos.x = 9800.0f;
	FireFox5.Monster_vPos.y = 400.0f;

	FireFox6.Monster_vPos.x = 9800.0f;
	FireFox6.Monster_vPos.y = 0.0f;

	FireFox7.Monster_vPos.x = 9800.0f;
	FireFox7.Monster_vPos.y = 200.0f;

	//-----------------------------------

	FireGhost.Monster_vPos.x = 1200.0f;
	FireGhost.Monster_vPos.y = 300.0f;

	FireGhost2.Monster_vPos.x = 2600.0f;
	FireGhost2.Monster_vPos.y = 200.0f;

	FireGhost3.Monster_vPos.x = 7500.0f;
	FireGhost3.Monster_vPos.y = 400.0f;

	FireGhost4.Monster_vPos.x = 9000.0f;
	FireGhost4.Monster_vPos.y = 200.0f;

	FireGhost5.Monster_vPos.x = 900.0f;
	FireGhost5.Monster_vPos.y = 200;

	FireGhost6.Monster_vPos.x = 900.0f;
	FireGhost6.Monster_vPos.y = 200.0f;

	FireGhost7.Monster_vPos.x = 900.0f;
	FireGhost7.Monster_vPos.y = 200.0f;

	ChogangKing.Init(m_pd3dDevice);

	return S_OK;
}

int CGame::Main(void)
{
	switch(GameState)
	{
	case 0:
		Draw();
        break;

    case 1:
		Draw();		
        break;

    case 2:
		PostQuitMessage(0);
        break;

    case 3:
		Draw();
        break;

    case 4:
		Draw();		
        break;
	case 5:
		Draw();		
        break;
	case 6:
		Draw();		
        break;
	case 7:
		Draw();		
        break;
	case 8:
		Draw();		
        break;
	case 9:
		Draw();		
        break;
	}
	return 0;
}

int CGame::Exit(void)
{
	MainScreen.Exit();	

	Character.Exit();
	Tilemap.Exit();
	Guardian.Exit();

	FireFox.Exit();
	FireFox2.Exit();
	FireFox3.Exit();
	FireFox4.Exit();
	FireFox5.Exit();
	FireFox6.Exit();
	FireFox7.Exit();

	FireGhost.Exit();
	FireGhost2.Exit();
	FireGhost3.Exit();
	FireGhost4.Exit();
	FireGhost5.Exit();
	FireGhost6.Exit();
	FireGhost7.Exit();

	Boss.Exit();		
	Hospital.Exit();
	Accident.Exit();
	MoodangHouse.Exit();
	SamDoChun.Exit();
	Text.Exit();

	if(m_pd3dDevice != NULL)
		m_pd3dDevice->Release();

	if(m_pD3D != NULL)
		m_pD3D->Release();
	return 0;
}

int CGame::Draw(void)
{
	// �ĸ� ���۸� ���(255,255,255)���� �����.
	m_pd3dDevice->Clear(0,NULL,D3DCLEAR_TARGET,D3DCOLOR_XRGB(255,255,255),1.0f,0);

	// �������� �����Ѵ�.
	if(SUCCEEDED(m_pd3dDevice->BeginScene()))
	{	
		// �� �ּ� ������ ���� ������ ���ɵ��� �����Ǳ� ������
		if(GameState==0) // ����ȭ��
		{	
			GameState = MainScreen.Change();
			MainScreen.Run();
		}
		if(GameState==1) // ������
		{			
			MainScreen.CreateDraw();
			if(GetAsyncKeyState(VK_ESCAPE)& 0x0001)
			{
				GameState = MainScreen.Change();
			}
		}
		if(GameState==3) // ������
		{
			GameState = Opening.Change();
			Opening.Draw();
		}
		if(GameState==4) // ����
		{
			GameState = Hospital.Change();
			Hospital.Draw(Character.m_vPos.x);
			Text.Draw();
			Character.Hospital_Check();
			if(GameState == 5)
			{
				Character.m_vPos.x = 100;
				Character.m_vPos.y = 300;
			}
		}
		if(GameState==5) // ������
		{
			GameState = Accident.Change();
			Accident.Draw(Character.m_vPos.x);
			if(GameState == 6)
			{
				Character.m_vPos.x = 100;
				Character.m_vPos.y = 300;
			}
		}
		if(GameState==6) // ������
		{
			GameState = MoodangHouse.Change();
			MoodangHouse.Draw(Character.m_vPos.x);
			Character.MoodangHouse_Check();
			if(GameState == 7)
			{
				Character.m_vPos.x = 100;
				Character.m_vPos.y = 300;
			}
		}
		if(GameState==7) // �ﵵõ
		{
			GameState = SamDoChun.Change();
			SamDoChun.Draw(Character.m_vPos.x);
			Character.SamDoChun_Check();
			if(GameState == 8)
			{
				Character.m_vPos.x = 100;
				Character.m_vPos.y = 300;
			}
		}
		if(GameState==8) // ȭ������
		{
			// �������� 1 ����
			Tilemap.Run(Tilemap.TilemapScroll(Character.m_vPos.x)); // �������� 1 Ÿ�ϸ� �׸���
			Guardian.Run(Character.m_vPos.x, Character.m_vPos.y,Guardian.MonsterScroll(Character.m_vPos.x),Character.m_Motion);

			FireFox.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox2.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox2.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox3.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox3.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox4.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox4.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox5.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox5.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox6.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox6.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireFox7.Run(Character.m_vPos.x, Character.m_vPos.y,FireFox7.MonsterScroll(Character.m_vPos.x),Character.m_Motion);

			FireGhost.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost2.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost2.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost3.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost3.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost4.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost4.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost5.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost5.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost6.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost6.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			FireGhost7.Run(Character.m_vPos.x, Character.m_vPos.y,FireGhost7.MonsterScroll(Character.m_vPos.x),Character.m_Motion);														

			Character.Run(Guardian.m_Mons_Motion,
				FireFox.m_Mons_Motion, FireFox2.m_Mons_Motion, FireFox3.m_Mons_Motion, FireFox4.m_Mons_Motion,
				FireFox5.m_Mons_Motion, FireFox6.m_Mons_Motion, FireFox7.m_Mons_Motion,
				FireGhost.m_Mons_Motion, FireGhost2.m_Mons_Motion, FireGhost3.m_Mons_Motion, FireGhost4.m_Mons_Motion,
				FireGhost5.m_Mons_Motion, FireGhost6.m_Mons_Motion, FireGhost7.m_Mons_Motion);
			Character.Fire_Check();	
			//Character.Hit_Check(Guardian.m_Mons_Motion);
			GameState = Tilemap.Boss_Choice(Character.m_vPos.x, Character.m_vPos.y);
			if(Character.Die() == 1)
			{
				GameState = 2;
			}
			if(GameState == 9)
			{
				Character.Character_Pos_Boss_Init();
			}
		}
		if(GameState==9) // ������
		{
			Boss.BossDraw(Boss.BossRoomMapScroll(Character.m_vPos.x)); // �������� 1 ������ �׸���
			ChogangKing.Run(Character.m_vPos.x, Character.m_vPos.y,ChogangKing.MonsterScroll(Character.m_vPos.x),Character.m_Motion);
			Character.Run(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			Character.Boss_Check();
		}
		// ������ ����
		m_pd3dDevice->EndScene();		
	}
	// �ĸ���۸� ���̴� ȭ������ ��ü
	m_pd3dDevice->Present(NULL,NULL,NULL,NULL);
	return 0;
}