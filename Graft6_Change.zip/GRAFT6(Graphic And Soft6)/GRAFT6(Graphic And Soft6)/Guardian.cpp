#include "Guardian.h"

CGuardian::CGuardian(void)
{
	mapPos = 0;
	// ������ ó�� ��ǥ
	Monster_vPos.x = 4500.0f;
	Monster_vPos.y = 350.0f;

	Monster_Rect.left	= 1024;
	Monster_Rect.right	= 1536;
	Monster_Rect.top	= 0;
	Monster_Rect.bottom	= 256;

	// ĳ���Ͱ� �������� ���� ���������� bool ���� L,R�Դϴ�
	m_Right_Check = true;
	m_Left_Check = false;		
	
	m_nStop_Count = 0;			// ��� �ϷḦ üũ�Ͽ� �ٸ� ȿ���� �������� �����Դϴ�.
	m_nDelay = 0;				// �����̸� �ֱ����� �����Դϴ�.
	m_nFrame = 0;				// ������ �����Դϴ�.
	m_nAction = 0;			
	m_nRandom = 0;				// 9���� ����� �������� �ޱ����� �����Դϴ�.
	m_nHit_Random = 1;			// 2���� �´� ����� �������� �ޱ����� �����Դϴ�.

	m_MoveStop_Frame = 0;
	m_Stand_By_Frame = 0;
	m_Move_Frame = 0;
	m_Attack_Frame = 0;
	m_Hit_Frame = 0;
	m_Down_Frame = 0;
	m_Die_Frame = 0;

	m_fHp = 150;

	// ĳ���� ���ڸ� �ޱ����� XY�����Դϴ�.
	m_Character_X = 0;				
	m_Character_Y = 0;				
	Distance = 0;
}

CGuardian::~CGuardian(void)
{
}

int CGuardian::Exit()
{
	if(m_pSprite != NULL)
		m_pSprite->Release();

	if(Monster_Texture != NULL)
		Monster_Texture->Release();

	return 0;
}

int CGuardian::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	m_pd3dDevice = pd3dDevice;
	D3DXCreateSprite(m_pd3dDevice,&m_pSprite);
	
	D3DXCreateTextureFromFile(m_pd3dDevice,L"����\\ȭ������\\������.png",&Monster_Texture);

	return 0;
}

int CGuardian::Draw(float MapPos_x)
{
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);

	DrawInit(m_pSprite,Monster_Texture,Monster_Rect,D3DXVECTOR3(0,0,0));

	m_vPos.x += MapPos_x + Monster_vPos.x;
	m_vPos.y += Monster_vPos.y;

	m_pSprite->Draw(Monster_Texture,&Monster_Rect,NULL,&m_vPos,D3DCOLOR_XRGB(255,255,255));

	m_pSprite->End();

	return 0;
}

int CGuardian::DrawInit(LPD3DXSPRITE pSprite, LPDIRECT3DTEXTURE9 m_pTexture, RECT rect, D3DXVECTOR3 vPos)
{
	m_pSprite		= pSprite;
	m_Texture		= m_pTexture;
	m_rect			= rect;
	m_vPos			= vPos;
	return 0;
}

int CGuardian::MonsterScroll(int Character_X)
{
	if(Character_X > 500) // ĳ������ ��ǥ�� 700�̻��� �ɶ�
	{
		int move = (int)Character_X-500; // ĳ������ ��ǥ������ 700 �� ���ذ��� move(���� �̵��� ��ŭ�� ��)�� �������ش�.
		mapPos -= move;	// ���� ��ǥ���� move ����ŭ �̵���Ų��.

		if(mapPos < (- 13775)) // ���� ������ ������ ���� �׸� �̵�
		{
			mapPos += move;
			return mapPos;
		}
		return mapPos;
	}
	else if(Character_X < 200) // ĳ������ ��ǥ�� 100���ϰ� �ɶ�
	{
		int move = 200-(int)Character_X; // ĳ������ ��ǥ���� move(���� �̵��� ��ŭ�� ��)�� �������ش�.
		mapPos += move; // ���� ��ǥ���� move ����ŭ �̵���Ų��.
		
		if(mapPos>0) // ���� ���� ������ ���� �׸� �̵�
		{
			mapPos -= move;
			return mapPos;
		}
		return mapPos;
	}
	return mapPos;
}


int CGuardian::Run(float x,float y,float MapPos_x, int Char_M)
{
	Draw(MapPos_x);
	AI(x,y, Char_M);
	return 0;
}

void CGuardian::Frame_Init(int StateNum)
{
	if(StateNum == 0)
	{
		//m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 1)
	{
		m_MoveStop_Frame = 0;
		//m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 2)
	{
		m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		//m_Move_Frame = 0;
		m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 3)
	{
		m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		//m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 4)
	{
		m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		m_Attack_Frame = 0;
		//m_Hit_Frame = 0;
		m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 5)
	{
		m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		//m_Down_Frame = 0;
		m_Die_Frame = 0;
	}
	if(StateNum == 6)
	{
		m_MoveStop_Frame = 0;
		m_Stand_By_Frame = 0;
		m_Move_Frame = 0;
		m_Attack_Frame = 0;
		m_Hit_Frame = 0;
		m_Down_Frame = 0;
		//m_Die_Frame = 0;
	}
	// ���� �浹ó���� �ϼ��Ǹ� �� �߰�.
}

void CGuardian::AI(float x, float y, int Char_M)
{
	m_Character_X = x;
	m_Character_Y = y;

	if(m_fHp > 0)
	{
		Distance = sqrt( (pow((m_Character_X-m_vPos.x),2)) + (pow((m_Character_Y-m_vPos.y),2)) );
	}
	if(Distance >= 600) // ��� ���� �Ÿ�
	{
		Frame_Init(1);
		Stand_By_State();
	}
	else if(Distance < 600 && Distance >= 400) // ��� ��� 9���� �Ÿ�
	{
		Idle_State();
	}
	else if(Distance < 400 && Distance >= 300) // ���� �ٶ󺸴� �Ÿ�
	{
		Frame_Init(1);
		Seeing_The_Enemy_State();
	}
	else if(Distance < 300 && Distance >= 120) // ĳ���Ϳ��� ������ ���� �Ÿ�
	{
		if(Monster_Collision(Char_M, x, y) == true)
		{
			Monster_Collision(Char_M, x, y);
			m_fHp -= 0.5;
			m_Mons_Motion = MOTION_WAIT;
		}
		else
		{
			Frame_Init(2);
			Move_State();
			m_Mons_Motion = MOTION_WAIT;
		}
	}
	else if(Distance < 120 && Distance >= 1) // ���� ��� ���ϴ� �Ÿ�
	{
		if(Monster_Collision(Char_M, x, y) == true)
		{
			Monster_Collision(Char_M, x, y);
			m_fHp -= 0.5;
			m_Mons_Motion = MOTION_WAIT;
		}
		else
		{
			Frame_Init(3);
			Attack_State();
			if(y+256>m_vPos.y+200 && y+256<m_vPos.y+300)
			{
				m_Mons_Motion = MOTION_HIT;
			}
		}
		
	}

	if(m_fHp == 0)
	{
		Distance = 0;
		Frame_Init(6);
		Die_State();
	}
}

void CGuardian::Stand_By_State() // ��⵿��
{
	if(m_Right_Check == true)
	{
		Monster_Animation(2,7,512,1024,1536,0,256);

		if(m_Character_X >= m_vPos.x) // ĳ���Ϳ� ������ ��ǥ�� �˻��Ͽ� ���� ������ üũ
		{
			m_Left_Check = true;
			m_Right_Check = false;
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation(2,7,512,0,512,0,256);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;			
		}	
	}
}

void CGuardian::Move_Stop() // ��� -> �ȱ� ���� ����
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Stop(2,7,512,1024,1536,0,256);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Stop(2,7,512,0,512,0,256);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Go() // �ȱ� ������ �̵��Ҷ�
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Left(6,7,512,0,512,512,768,4.5f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Right(6,7,512,0,512,256,512,4.5f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Back() //////////////////////////
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Right(6,7,512,0,512,256,512,4.5f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Left(6,7,512,0,512,512,768,4.5f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Up()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Up(6,7,512,0,512,512,768,4.5f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Up(6,7,512,0,512,256,512,4.5f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Down()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Down(6,7,512,0,512,512,768,4.5f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Down(6,7,512,0,512,256,512,4.5f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Go_Up()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Left_Diagonal_Up(6,7,512,0,512,512,768,3.2f,3.2f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Right_Diagonal_Up(6,7,512,0,512,256,512,3.2f,3.2f);
	
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Go_Down()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Left_Diagonal_Down(6,7,512,0,512,512,768,3.2f,3.2f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Right_Diagonal_Down(6,7,512,0,512,256,512,3.2f,3.2f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Back_Down()////////////////////////
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Right_Diagonal_Down(6,7,512,0,512,256,512,3.2f,3.2f);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Left_Diagonal_Down(6,7,512,0,512,512,768,3.2f,3.2f);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_Back_Up() ////////////////////////////////
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Move_Right_Diagonal_Up(6,7,512,0,512,256,512,3.2f,3.2f);
		
		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Move_Left_Diagonal_Up(6,7,512,0,512,512,768,3.2f,3.2f);
		
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Idle_State()
{
	switch(m_nRandom)
	{
	case Move_Stop_:
		Frame_Init(0);
		Move_Stop();
		break;
	case Move_Go_:
		Frame_Init(2);
		Move_Go();
		break;
	case Move_Back_:
		Frame_Init(2);
		Move_Back();
		break;
	case Move_Up_:
		Frame_Init(2);
		Move_Up();
		break;
	case Move_Down_:
		Frame_Init(2);
		Move_Down();
		break;
	case Move_Go_Up_:
		Frame_Init(2);
		Move_Go_Up();
		break;
	case Move_Go_Down_:
		Frame_Init(2);
		Move_Go_Down();
		break;
	case Move_Back_Up_:
		Frame_Init(2);
		Move_Back_Up();
		break;
	case Move_Back_Down_:
		Frame_Init(2);
		Move_Back_Down();
		break;
	}
}

void CGuardian::Seeing_The_Enemy_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation(2,7,512,1024,1536,0,256);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation(2,7,512,0,512,0,256);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Move_State_Right_Move()
{
	if(m_Character_X <= m_vPos.x)
	{
		Monster_vPos.x -= 4.5f;
	}

	if(m_Character_Y >= m_vPos.y)
	{
		Monster_vPos.y += 4.5f;
	}
	else if (m_Character_Y <= m_vPos.y)
	{
		Monster_vPos.y -= 4.5f;
	}
}

void CGuardian::Move_State_Left_Move()
{
	if(m_Character_X >= m_vPos.x)
	{
		Monster_vPos.x += 4.5f;
	}

	if(m_Character_Y >= m_vPos.y)
	{
		Monster_vPos.y += 4.5f;
	}
	else if (m_Character_Y <= m_vPos.y)
	{
		Monster_vPos.y -= 4.5f;
	}
}

void CGuardian::Move_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Right_Check_Move_State(6,7,512,0,512,512,768);
		
		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Left_Check_Move_State(6,7,512,0,512,256,512);
	
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}

}

void CGuardian::Attack_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Attack(6,6,512,0,512,1024,1280);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Attack(6,6,512,0,512,768,1024);
	
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

///////////////////////////////////////////////////
//�ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ�
///////////////////////////////////////////////////

void CGuardian::Die_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Die(7,10,512,0,512,2304,2560);

		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Die(7,10,512,0,512,2048,2304);

		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

void CGuardian::Hit_Body_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Hit(3,10,512,1536,2048,1280,1536);
	
		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Hit(3,10,512,0,512,1280,1536);
	
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}

}

void CGuardian::Down_State()
{
	if(m_Right_Check == true)
	{
		Monster_Animation_Down(7,10,512,0,512,1792,2048);
		
		if(m_Character_X >= m_vPos.x)
		{
			m_Left_Check = true;
			m_Right_Check = false;			
		}
	}

	if(m_Left_Check == true)
	{
		Monster_Animation_Down(7,10,512,0,512,1536,1792);
	
		if(m_Character_X  <= m_vPos.x)
		{
			m_Left_Check = false;
			m_Right_Check = true;
		}
	}
}

////////////////////////////////////////////////////////////////////////////
// �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ� �ּ�
////////////////////////////////////////////////////////////////////////////

void CGuardian::Monster_Animation(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Stand_By_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Stand_By_Frame++;
		}
		else if(m_Stand_By_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Stand_By_Frame++;
		}
		else
		{
			m_Stand_By_Frame = 0;
		}
	}
}


void CGuardian::Monster_Animation_Stop(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_MoveStop_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_MoveStop_Frame++;
		}
		else if(m_MoveStop_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_MoveStop_Frame++;
		}
		else
		{
			m_MoveStop_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = rand() % 8 + 1;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Left(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Right(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Up(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom,float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Down(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Left_Diagonal_Up(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X, float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Right_Diagonal_Up(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X, float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			Monster_vPos.y -= Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Left_Diagonal_Down(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X, float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x -= Monster_X;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}

void CGuardian::Monster_Animation_Move_Right_Diagonal_Down(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom, float Monster_X, float Monster_Y)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Monster_vPos.x += Monster_X;
			Monster_vPos.y += Monster_Y;
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
			m_nStop_Count++;
		}
		if(m_nStop_Count == 2)
		{
			m_nRandom = 0;
			m_nStop_Count = 0;
		}
	}
}
void CGuardian::Monster_Animation_Right_Check_Move_State(int Frame, int Delay, int Price,int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Move_State_Right_Move();
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Move_State_Right_Move();
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
		}
	}
}

void CGuardian::Monster_Animation_Left_Check_Move_State(int Frame, int Delay, int Price,int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Move_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Move_State_Left_Move();
			m_Move_Frame++;
		}
		else if(m_Move_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			Move_State_Left_Move();
			m_Move_Frame++;
		}
		else
		{
			m_Move_Frame = 0;
		}
	}	
}

void CGuardian::Monster_Animation_Attack(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Attack_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Attack_Frame++;
		}
		else if(m_Attack_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Attack_Frame++;
		}
		else
		{
			m_Attack_Frame = 0;
		}
	}	
}

void CGuardian::Monster_Animation_Hit(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Hit_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Hit_Frame++;
		}
		else if(m_Hit_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Hit_Frame++;
		}
		else
		{
			m_Hit_Frame = 0;
		}
	}
}

void CGuardian::Monster_Animation_Down(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay++;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Down_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Down_Frame++;
		}
		else if(m_Down_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Down_Frame++;
		}
		else
		{
			m_Down_Frame = 0;
		}
	}
}

void CGuardian::Monster_Animation_Die(int Frame, int Delay, int Price, int Left, int Right, int Top, int Bottom)
{
	m_nDelay += 1;
	
	if(m_nDelay >= Delay)
	{
		m_nDelay = 0;
		if(m_Die_Frame == 0)
		{
			Monster_Rect.left = Left;
			Monster_Rect.right = Right;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Die_Frame++;
		}
		else if(m_Die_Frame < Frame)
		{
			Monster_Rect.left += Price;
			Monster_Rect.right += Price;
			Monster_Rect.top = Top;
			Monster_Rect.bottom = Bottom;
			m_Die_Frame++;
		}
		else
		{
			/*m_Die_Frame = 0;*/
		}
	}
}

int CGuardian::Monster_Collision(int Character_M, float charX, float charY)
{
	 //MOTION_RIGHT_BASIC_ATTACK1 = 12 (Z) // MOTION_RIGHT_BASIC_ATTACK2 = 14 (Z) // MOTION_RIGHT_BASIC_ATTACK3 = 16 (Z) // MOTION_RIGHT_SKILL_ATTACK1 (A)
	if(Character_M == 12 || Character_M == 14 || Character_M == 16 || Character_M == 18)
	{
		if( charX+150<m_vPos.x+150 && charX +150> m_vPos.x && charY+256>m_vPos.y+200 && charY+256<=m_vPos.y+300)
		{
			if(m_fHp > 50)
			{
				Frame_Init(4);
				Hit_Body_State();
			}
			else if(0 < m_fHp && m_fHp < 50)
			{
				Frame_Init(5);
				Down_State();
			}
			return true;
		}
		return false;
	}
	//MOTION_RIGHT_SKILL_ATTACK2 = 20 (S) // MOTION_RIGHT_SKILL_ATTACK3 (D)
	if(Character_M == 20 || Character_M == 22)
	{
		if(charX+200<m_vPos.x +120&&charX +200> m_vPos.x && charY+256>m_vPos.y+200 && charY+256<=m_vPos.y+300)
		{
			if(m_fHp > 50)
			{
				Frame_Init(4);
				Hit_Body_State();
			}
			else if(0 < m_fHp && m_fHp < 50)
			{
				Frame_Init(5);
				Down_State();
			}
			return true;
		}
		return false;
	}
	 //MOTION_LEFT_BASIC_ATTACK1 = 13 (Z) // MOTION_LEFT_BASIC_ATTACK2 = 15 (Z) // MOTION_LEFT_BASIC_ATTACK3 = 17 (Z) // MOTION_LEFT_SKILL_ATTACK1 = 19(A)
	if(Character_M == 13 || Character_M == 15 || Character_M == 17 || Character_M == 19)
	{
		if(charX>m_vPos.x +30&& charX<m_vPos.x+200 && charY+256>m_vPos.y+200 && charY+256<=m_vPos.y+300)
		{
			if(m_fHp > 50)
			{
				Frame_Init(4);
				Hit_Body_State();
			}
			else if(0 < m_fHp && m_fHp < 50)
			{
				Frame_Init(5);
				Down_State();
			}
			return true;
		}
		return false;
	}
	//MOTION_LEFT_SKILL_ATTACK2 = 21 (S) // MOTION_LEFT_SKILL_ATTACK3 = 23 (D)
	if(Character_M == 21 || Character_M == 23)
	{
		if(charX>m_vPos.x+70 && charX < m_vPos.x+200 && charY+256>m_vPos.y+200 && charY+256<=m_vPos.y+300)
		{
			if(m_fHp > 50)
			{
				Frame_Init(4);
				Hit_Body_State();
			}
			else if(0 < m_fHp && m_fHp < 50)
			{
				Frame_Init(5);
				Down_State();
			}
			return true;
		}
		return false;
	}
	return false;

}