#include "Music.h"

CMusic::CMusic(void)
{
}

CMusic::~CMusic(void)
{
}

void CMusic::LoadBGMFile(LPCWSTR lpszWave, UINT &BGMDeviceID)
{
	// ��ġ�� Open�ϰ� ID�� �߱޹޴´�.
	Open.lpstrElementName = lpszWave;
	Open.lpstrDeviceType = L"MPEGVideo";

    mciSendCommand(NULL,MCI_OPEN,MCI_OPEN_ELEMENT|MCI_OPEN_TYPE, (DWORD)(LPVOID)&Open);        
	BGMDeviceID = Open.wDeviceID;                     //���� ����̽� ���̵� �޴´�.

    MCI_STATUS_PARMS m_mciStatusParms;
	m_mciStatusParms.dwItem = MCI_STATUS_LENGTH;

    mciSendCommand(BGMDeviceID, MCI_STATUS, MCI_STATUS_ITEM, (DWORD)(LPVOID)&m_mciStatusParms);
    m_nTotalTime = (LONG)m_mciStatusParms.dwReturn;
}

void CMusic::LoadEFTFile(LPCWSTR lpszWave, UINT &EFTDeviceID)// ȿ����
{
	Open.lpstrElementName = lpszWave;
	Open.lpstrDeviceType = L"MPEGVideo";

    mciSendCommand(NULL,MCI_OPEN,MCI_OPEN_ELEMENT|MCI_OPEN_TYPE, (DWORD)(LPVOID)&Open);        
	EFTDeviceID = Open.wDeviceID;                     //���� ����̽� ���̵� �޴´�.

    MCI_STATUS_PARMS m_mciStatusParms;
	m_mciStatusParms.dwItem = MCI_STATUS_LENGTH;

    mciSendCommand(EFTDeviceID, MCI_STATUS, MCI_STATUS_ITEM, (DWORD)(LPVOID)&m_mciStatusParms);
    m_nTotalTime = (LONG)m_mciStatusParms.dwReturn;

}

DWORD CMusic::PlayBGM(UINT &BGMDeviceID)
{
	mciSendCommand(BGMDeviceID,MCI_PLAY,MCI_FROM | MCI_DGV_PLAY_REPEAT, (DWORD)(LPVOID) &Play);
	return true;
}

DWORD CMusic::StopBGM(UINT &BGMDeviceID)
{
    mciSendCommand(BGMDeviceID,MCI_STOP,MCI_NOTIFY, (DWORD)(LPVOID) &Play);
    return true;
}

DWORD CMusic::PlayEFT(UINT &EFTDeviceID)
{
	mciSendCommand(EFTDeviceID,MCI_PLAY,MCI_FROM, (DWORD)(LPVOID) &Play);
	return true;
}
DWORD CMusic::StopEFT(UINT &EFTDeviceID)
{
    mciSendCommand(EFTDeviceID,MCI_STOP,MCI_NOTIFY, (DWORD)(LPVOID) &Play);
    return true;
}
