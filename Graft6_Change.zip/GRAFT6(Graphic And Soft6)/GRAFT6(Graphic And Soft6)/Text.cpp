#include "Text.h"

DWORD m_nDelay = 0;
bool Next = true;

CText::CText(void)
{	
	Font_49 = NULL;

	m_Text_Rect.left = 270;
	m_Text_Rect.top = 35;
	m_Text_Rect.right = 0;
	m_Text_Rect.bottom = 0;

	m_Images_Rect.left = 0;
	m_Images_Rect.top = 0;
	m_Images_Rect.right = 1024;
	m_Images_Rect.bottom = 256;

	m_vPos_Images.x = 15;
	m_vPos_Images.y = 15;
	m_vPos_Images.z = 0;

	//m_nDelay = 0;
}

CText::~CText(void)
{
}

void CText::Exit()
{
	if(Font_49 != NULL)
		Font_49->Release();

	if(m_pSprite != NULL)
		m_pSprite->Release();

	if(m_pd3dDevice_Text != NULL)
		m_pd3dDevice_Text->Release();

	if(m_pd3dDevice_Images != NULL)
		m_pd3dDevice_Images->Release();

	if(m_Texture_Ari != NULL)
		m_Texture_Ari->Release();

	if(m_Texture_Secretary != NULL)
		m_Texture_Secretary->Release();

	if(m_Texture_Kimdoujin != NULL)
		m_Texture_Kimdoujin->Release();
}

void CText::Init_Text(LPDIRECT3DDEVICE9 Device)
{
	m_pd3dDevice_Text = Device;
	//D3DXCreateFont(m_pd3dDevice_Text,20,10,FW_THIN,1,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,
		//DEFAULT_QUALITY,DEFAULT_PITCH | FF_DONTCARE,L"����",&Font_49);
	//INT height = ���� ũ�� //INT width = ĭ ���� // FW_�ø��� = ���� ���
	// TRUE = ���� FALSE = ���⸦ ������� ����
	
	D3DXFONT_DESC fontDesc;
	ZeroMemory(&fontDesc,sizeof(fontDesc));
	lstrcpy(fontDesc.FaceName,L"�ü�");
	fontDesc.Height = 35; // ����ũ��
	fontDesc.Width = 12; // ĭ����
	fontDesc.Weight = FW_MEDIUM; // ���ھ��
	fontDesc.MipLevels = 0; // ����Ƽ
	fontDesc.Italic = false; // ����
	fontDesc.CharSet = DEFAULT_CHARSET;
	fontDesc.Quality = DEFAULT_QUALITY;
	fontDesc.PitchAndFamily = FF_DONTCARE;
	fontDesc.OutputPrecision = OUT_DEFAULT_PRECIS;

	D3DXCreateFontIndirect(m_pd3dDevice_Text,&fontDesc,&Font_49);
	D3DXCreateSprite(m_pd3dDevice_Text,&m_pSprite);

}

void CText::Init_Images(LPDIRECT3DDEVICE9	Device)
{
	m_pd3dDevice_Images = Device;
	D3DXCreateSprite(m_pd3dDevice_Images,&m_pSprite);

	D3DXCreateTextureFromFile(m_pd3dDevice_Images,L"Text\\Ari.png",&m_Texture_Ari);
	D3DXCreateTextureFromFile(m_pd3dDevice_Images,L"Text\\Secretary.png",&m_Texture_Secretary);
	D3DXCreateTextureFromFile(m_pd3dDevice_Images,L"Text\\Kimdoujin.png",&m_Texture_Kimdoujin);
}

void CText::Draw()
{
	TextCombination();
}

void CText::Run()
{
	Draw();
}

void CText::mText(LPCWSTR Str)
{
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);
	Font_49->DrawTextW(m_pSprite,Str,-1,&m_Text_Rect,DT_SINGLELINE | DT_NOCLIP,D3DCOLOR_XRGB(255,255,255));
	m_pSprite->End();	
}

void CText::Ari_Draw()
{
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);
	m_pSprite->Draw(m_Texture_Ari,&m_Images_Rect,NULL,&m_vPos_Images,D3DCOLOR_XRGB(255,255,255));
	m_pSprite->End();
}

void CText::Secretary_Draw()
{
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);
	m_pSprite->Draw(m_Texture_Secretary,&m_Images_Rect,NULL,&m_vPos_Images,D3DCOLOR_XRGB(255,255,255));
	m_pSprite->End();
}

void CText::Kimdoujin_Draw()
{
	m_pSprite->Begin(D3DXSPRITE_ALPHABLEND | D3DXSPRITE_SORT_TEXTURE);
	m_pSprite->Draw(m_Texture_Kimdoujin,&m_Images_Rect,NULL,&m_vPos_Images,D3DCOLOR_XRGB(255,255,255));
	m_pSprite->End();
}

void CText::TextCombination()
{
	if(m_nDelay == 0)
	{
		mText(L"");
	}

	else if(m_nDelay == 1)
	{
		Kimdoujin_Draw();
		mText(L"......");
	}

	else if(m_nDelay == 2)
	{
		Secretary_Draw();
		mText(L"ũũũ... ����� �ֻ����� ��������.");
	}

	else if(m_nDelay == 3)
	{
		Secretary_Draw();
		mText(L"���� ����� ������ ���ڴ�.");
	}

	else if(m_nDelay == 4)
	{
		Kimdoujin_Draw();
		mText(L"......");
	}

	else if(m_nDelay == 5)
	{
		Ari_Draw();
		mText(L"�Ƿ���� ���˽ð��Դϴ�.");
	}

	else if(m_nDelay == 6)
	{
		Secretary_Draw();
		mText(L"��.. ���� �̷�����...");
	}

	else if(m_nDelay == 7)
	{
		Kimdoujin_Draw();
		mText(L"......");
	}

	else if(m_nDelay == 8)
	{
		Secretary_Draw();
		mText(L"���Ѱ� �ƴϴ�... ������ �ٽ� ã�ƿ����� ������");
	}


	if(Next == true)
	{
		if(GetAsyncKeyState(VK_SPACE))
		{
			m_nDelay += 1;
			Next = false;
		}
	}

	if(!(GetAsyncKeyState(VK_SPACE)))
	{
		Next = true;
	}
}