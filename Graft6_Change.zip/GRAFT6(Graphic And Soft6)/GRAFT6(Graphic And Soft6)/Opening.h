#pragma once
#include "Defines.h"

class COpening
{
public:
	COpening(void);
	~COpening(void);
private:
	LPDIRECT3D9 m_pD3D;
	LPDIRECT3DDEVICE9 m_pd3dDevice;
	LPD3DXSPRITE m_pSprite;
	LPDIRECT3DTEXTURE9 Opening_Texture[11];

	CMusic Music; // ���� Ŭ����
public:
	int Exit(void);
	int Init(LPDIRECT3DDEVICE9 pd3dDevice);
	int Run(void);
	int Draw(void);
	int Choice(void);
	int Select;
	int Change(void);
	bool Enter_Bool;
private:
	bool Bgm_Opening_Bool;
	bool Eft_Car_Crash_Bool;
};
