#pragma once
#include "Defines.h"

class CMainScreen 
{
public:
	CMainScreen(void);
	~CMainScreen(void);
private:
	LPD3DXSPRITE m_pSprite;
	LPDIRECT3DDEVICE9 m_pd3dDevice;

	LPDIRECT3DTEXTURE9 MainScreen;
	LPDIRECT3DTEXTURE9 Start;
	LPDIRECT3DTEXTURE9 Creater;
	LPDIRECT3DTEXTURE9 Quit;

	LPDIRECT3DTEXTURE9 Creater_Select;

	D3DXVECTOR3	Start_Pos;
	D3DXVECTOR3	Creater_Pos;
	D3DXVECTOR3	Quit_Pos;
		
	void Choice(void);
	int Select;

	CMusic Music; // ���� Ŭ����
public:
	int Exit(void);
	int Init(LPDIRECT3DDEVICE9 pd3dDevice);
	int Run(void);
	int Draw(void);
	int Change(void);
	int CreateDraw(void);
private:
	bool Bgm_Intro_Bool;
};