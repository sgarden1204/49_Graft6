#include "Opening.h"

COpening::COpening(void)
: Select(0)
, Enter_Bool(false)
, Bgm_Opening_Bool(false)
, Eft_Car_Crash_Bool(false)
{
}

COpening::~COpening(void)
{
}
int COpening::Exit(void)
{
	if( Opening_Texture[0] != NULL )
        Opening_Texture[0]->Release();

	if( Opening_Texture[1] != NULL )
        Opening_Texture[1]->Release();

	if( Opening_Texture[2] != NULL )
        Opening_Texture[2]->Release();

	if( Opening_Texture[3] != NULL )
        Opening_Texture[3]->Release();

	if( Opening_Texture[4] != NULL )
        Opening_Texture[4]->Release();

	if( Opening_Texture[5] != NULL )
        Opening_Texture[5]->Release();

	if( Opening_Texture[6] != NULL )
        Opening_Texture[6]->Release();

	if( Opening_Texture[7] != NULL )
        Opening_Texture[7]->Release();

	if( Opening_Texture[8] != NULL )
        Opening_Texture[8]->Release();

	if( Opening_Texture[9] != NULL )
        Opening_Texture[9]->Release();

	if( Opening_Texture[10] != NULL )
        Opening_Texture[10]->Release();

	if( m_pSprite != NULL )
        m_pSprite->Release();
	return 0;
}

int COpening::Init(LPDIRECT3DDEVICE9 pd3dDevice)
{
	m_pd3dDevice = pd3dDevice;
	D3DXCreateSprite( m_pd3dDevice, &m_pSprite );

	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\1.jpg",&Opening_Texture[0]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\2.jpg",&Opening_Texture[1]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\3.jpg",&Opening_Texture[2]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\4.jpg",&Opening_Texture[3]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\5.jpg",&Opening_Texture[4]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\6.jpg",&Opening_Texture[5]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\7.jpg",&Opening_Texture[6]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\8.jpg",&Opening_Texture[7]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\9.jpg",&Opening_Texture[8]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\10.jpg",&Opening_Texture[9]);
	D3DXCreateTextureFromFile(m_pd3dDevice,L"������\\11.jpg",&Opening_Texture[10]);

	Music.LoadBGMFile(L"����\\BGM\\Bgm_Opening.mp3",Music.BGMDeviceID[BGM_OPENING]);
	Music.LoadEFTFile(L"����\\EFT\\Eft_Car_Crash.mp3",Music.EFTDeviceID[Eft_CAR_CRASH]);

	return 0;
}

int COpening::Run(void)
{
	Draw();
	return 0;
}

int COpening::Draw(void)
{
	if( SUCCEEDED( m_pSprite->Begin(D3DXSPRITE_ALPHABLEND ) ) )
    {
		if(Bgm_Opening_Bool == false)
		{
			Music.PlayBGM(Music.BGMDeviceID[BGM_OPENING]);
			Bgm_Opening_Bool = true;
		}
		Choice();
		// �׸���
		if(Select ==0)
			m_pSprite->Draw(Opening_Texture[0], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 1)
			m_pSprite->Draw(Opening_Texture[1], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 2)
			m_pSprite->Draw(Opening_Texture[2], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 3)
			m_pSprite->Draw(Opening_Texture[3], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 4)
			m_pSprite->Draw(Opening_Texture[4], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 5)
			m_pSprite->Draw(Opening_Texture[5], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 6)
		{
			if(Eft_Car_Crash_Bool==false)
			{
				Music.PlayEFT(Music.EFTDeviceID[Eft_CAR_CRASH]);
				Eft_Car_Crash_Bool=true;
			}
			m_pSprite->Draw(Opening_Texture[6], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		}
		else if(Select == 7)
			m_pSprite->Draw(Opening_Texture[7], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 8)
			m_pSprite->Draw(Opening_Texture[8], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		else if(Select == 9)
		{
			Music.StopEFT(Music.EFTDeviceID[Eft_CAR_CRASH]);
			Eft_Car_Crash_Bool=false;
			m_pSprite->Draw(Opening_Texture[9], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		}
		else
			m_pSprite->Draw(Opening_Texture[10], NULL, NULL,NULL, D3DCOLOR_XRGB(255,255,255));
		// ��������Ʈ ������ ����
        m_pSprite->End();
    }
	return 0;
}

int COpening::Choice(void)
{
	if(Enter_Bool == false)
	{
		if(GetAsyncKeyState(VK_RETURN))
		{
			Select += 1;
			Enter_Bool = true;
		}
	}
	if(!(GetAsyncKeyState(VK_RETURN)))
	{
		Enter_Bool = false;
	}
	return 0;
}

int COpening::Change(void)
{
	if(Select == 12)
	{
		Music.StopBGM(Music.BGMDeviceID[BGM_OPENING]);
		return 4;
	}
	return 3;
}
